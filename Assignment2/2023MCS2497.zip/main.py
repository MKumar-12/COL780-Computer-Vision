import os
import sys
from reader import *
from helpers import *

# Creation of Panaroma from given set of images in a DIR
def stitch_images_from_paths(image_paths, output_path):
    images = [cv2.imread(image_path) for image_path in image_paths]

    if not images:
        print(f"[ERROR] No images found in '{image_paths}'.")
        return

    print(f"Found {len(images)} images.")

    ref_image, _, _ = ProjectOntoCylinder(images[0])
    for i, img in enumerate(images[1:], start=1):
        print(f"Iteration : {i}")
        stitched_image = StitchImages(ref_image, img)
        ref_image = stitched_image.copy()

    output_file_loc = os.path.join(output_path, "Stitched_Panorama.png")
    cv2.imwrite(output_file_loc, ref_image)
    print(f"[SUCCESS] Panoramic image generated at location: '{output_path}'")


if __name__ == "__main__":   
    if len(sys.argv) != 4:
        print("Usage: python main.py <part_id> <img_dir> <output_dir>")
        sys.exit(1)

    part_id = int(sys.argv[1])
    input_path = sys.argv[2]
    output_path = sys.argv[3]

    if not os.path.exists(input_path):
        print(f"[ERROR] Input path '{input_path}' does not exist.")
        sys.exit(1)

    if part_id == 1:
        stitch_images_from_paths(open_img_files(input_path), output_path)
    elif part_id == 2:
        stitch_images_from_paths(open_video_file(input_path), output_path)
    else:
        print("[ERROR] Invalid part id. Must be either 1 or 2...")