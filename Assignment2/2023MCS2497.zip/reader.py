import os
import cv2


# To Read all images from the given dir.
def open_img_files(image_directory):
    # Storre the curr main data dir :
    main_directory = os.getcwd() 
    data_path = os.path.join(main_directory, image_directory)

    #Storing the list of images :
    image_paths = []
    
    if os.path.exists(data_path):
        for filename in os.listdir(data_path):
            if isinstance(filename, str):  # Ensure filename is a string
                img_path = os.path.join(data_path, filename)
                image_paths.append(img_path)
            else:
                print(f"[WARNING]Skipping non-string filename: {filename}")

    else:
        print(f"[ERROR]The '{image_directory}' subfolder does not exist in the present directory!")
    
    return image_paths


# To Read video from the given dir. & generate screenshots from it every 1s
def open_video_file(video_directory):
    main_directory = os.getcwd() 
    data_path = os.path.join(main_directory, video_directory)

    #Storing the list of extracted images :
    image_paths = []

    if os.path.exists(data_path):
        # Open the video file
        cap = cv2.VideoCapture(data_path)
        if not cap.isOpened():
            print(f"[ERROR] Could not open video file: {data_path}")
            return image_paths

        # Create a folder 'src' to store frames captured from video
        generated_directory = os.path.join(main_directory, "src")
        if not os.path.exists(generated_directory):
            os.makedirs(generated_directory)

        # Extracting frames at 1-second intervals 
        frame_rate = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(frame_rate * 1)
        frame_ctr = 0
        success, image = cap.read()
        while success:
            image_paths.append(os.path.join(generated_directory, f"frame_{frame_ctr}.jpg"))
            cv2.imwrite(os.path.join(generated_directory, f"frame_{frame_ctr}.jpg"), image)
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_ctr + frame_interval)
            success, image = cap.read()
            frame_ctr += frame_interval

        cap.release()

    else:
        print(f"[ERROR]The '{video_directory}' subfolder does not exist in the present directory!")    

    return image_paths